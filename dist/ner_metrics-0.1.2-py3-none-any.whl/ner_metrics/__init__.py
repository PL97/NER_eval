from .ner_metrics import classification_report

__version__ = "0.1.1"
__author__ = "Le Peng"